﻿namespace Storage.Models;

public class FileListResult
{
    public string Name { get; set; }
    public bool IsDirectory { get; set; }
}